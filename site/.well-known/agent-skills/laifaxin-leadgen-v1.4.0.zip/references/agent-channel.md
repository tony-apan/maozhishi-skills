---
doc_id: laifaxin-agent-channel
title: 官方 Agent 通道（接口映射与调用纪律）
description: 来发信官方 Agent Skill 作为本 skill 首选执行通道的接入、接口映射（带证据等级）、调用纪律与降级规则；绑箱动作维持网页通道。
status: active
updated: 2026-11-19
owner: 贸知事
---

# 官方 Agent 通道（接口映射与调用纪律）

## 这是什么

来发信官方提供的 Agent 接入（接入页 https://agent.laifa.xin ）：一个装在用户本机的官方 Skill，通过网页授权拿到一枚可单独撤销的应用凭据，之后调用来发信平台的 Web 接口完成查询与操作。本 skill 把它定为**首选执行通道**：规则、台账、额度闸与发送确认闸仍全部在本 skill，官方通道只负责「把操作送达平台」，它只换执行路径——接口直达，不再逐页模拟点击；稳不稳以各接口的证据等级为准（见下表），不预设。

## 接入与授权（细则在 SKILL.md §1.1 第 1 步、§1.2）

1. 安装：按接入页现行说明装官方 Skill（一行安装或压缩包手工安装，装到宿主的技能目录）。
2. 配置与授权：由 AI 发起网页授权，把授权链接与用户码**原样**发给用户；用户本人在网页登录、核对用户码一致、选对工作空间、点「允许授权」；官方工具随即在用户本机完成凭据的交换与保存（AI 不接触凭据本身），AI 只查连接状态，账号与工作空间读回正确才算连上。用户明确选择委托代办时，按 SKILL §1.1 的保险库路径走：AI 弹出所在助手自带的安全凭据录入卡，用户在卡里填账号密码存入保险库（AI 看不到明文、不发链接或自制表单；无此卡时才引导用户自己打开凭据保管，无保险库则回默认路径），AI 只打开官方工具给出的授权链接、用保险库凭据登录（凭据由保险库填充、AI 不读明文），逐字核对用户码与工作空间无误才代点允许，核对不上即停手转用户；委托只管这一次授权，遇滑块、短信等真人验证立即停手、转用户本人，验证码也不经聊天代填；用户没明确委托，走本人点允许的默认路径。
3. 查连接状态只读官方工具的输出（凭据字段由其自动遮盖）；万一见到未遮盖的凭据值，立即停手、不复制、不记录、不写进任何文件。凭据由官方工具保存在用户本机（权限受限的配置文件），**本 skill 不读取、不保存、不经手**；有效期 30 天、无自动续期，到期重走第 2 步（用户再点一次允许）。用户可在来发信网页端「个人设置 → 安全设置 → 已授权应用」随时撤销。
4. 授权失败或过期：把平台返回的提示如实告诉用户并重走授权；**不改用密码登录、不读取浏览器 Cookie 或会话**（官方连接口径，与 R23 一致）。
5. 宿主跑不了本机脚本时本通道不可用，按 SKILL.md §1.4 降级卡全面回网页操作。

## 接口映射（证据等级按 R26 标注）

证据等级说明：**读实测**＝2026-11-16 以个人 SVIP 账号（z7pvxh）经网页授权凭据逐一真实调用成功，实测接口共四个：/expenses/give-status、/sequences/sequence-list、/contacts/companies/show、/mails/mails-list；表中标「读：实测」的行即指这四个，其余读接口仍属契约级；**契约级**＝官方接口目录在册、参数契约经官方前端源码核对吻合，写操作未在真实账号试执行——首次经接口执行时按 §4 章首要求先小步验证、回读确认再放量。

| 本 skill 操作 | 官方接口（路径） | 证据等级 |
| --- | --- | --- |
| 搜客·AI 数据库（找新客） | /refine/company-list（关键词/客群 query_en；**结果不带 domain 字段，取种子域名须另调 /domain/base-info**）、/refine/company-list-by-name、/domain/resolve-domain-name | 实测（2026-11-18） |
| 搜客·已保存公司检索 | /contacts/company-search（**只搜账号已保存公司**，客户管理内按名检索用；不用于搜新客）、/contacts/people-search（**只搜账号已保存联系人**，与 company-search 同口径；不用于搜新客） | company-search 实测（2026-11-18）；people-search 契约级 |
| 公司详情/搜相似 | /domain/base-info（公司 id 或域名均可）、/domain/similar-list | 实测（2026-11-18；similar-list 接口调用已实测，跨语种相关性为单种子抽样观察：德语种子前 5 家 5/5 相关，非全量验证） |
| AI 推演客群 | /profile/inference-product-add、inference-segment-generate、inference-segment-list、inference-product-save | 实测（2026-11-18；建产品与生成客群各扣 2 点） |
| 批量搜索任务 | /refine/task-create、task-list、task-info、task-status、task-delete | 链路实测可用（2026-11-18 阶段 0：create 建完即 finished、delete 后 list 回读确认已删、info 可读回）；**计费口径未证实**（源码口径「有效 −2/未知 −1/无效 0」在本轮实测中未发生——任务计数全 0、creditCount 前后不变，不得作为计费依据，待后续核实） |
| 搜客·领英/地图/谷歌 | /search/linkedin-company-v2-*、/search/map-data-*、/clouds/google-search/* | 契约级 |
| AI 评分全流程 | /clues/rating-task-*（建/启/停）、/clues/rating-result-*（结果/存联系人/存禁发） | 契约级（含存联系人/存禁发等写动作，未实测） |
| 保存与管理联系人/公司 | /contacts/companies/save、/contacts/* 管理族 | 读：实测｜写：部分实测（companies/save 改 short_description、phone_number 已实测可写；contact/add 带 c_id 写入与回查已实测；contact/delete 已实测；其余管理族契约级） |
| 补关联/补字段（查重命中后） | /contacts/contact/save（saveContactField 语义：{cid, 字段名: 值} 逐字段保存）；撞重取 cid 走 /contacts/contacts/show 的 email 精确匹配回查（/contacts/email-info 契约级） | 实测（2026-11-19：{cid, c_id, c_name} 改挂公司落地、{cid, remark} 可写、补后回读已核；**name 字段传值返回 success 但回读不生效，补姓名走网页端联系人编辑**） |
| 公司字段注册表 | /fields/company-fields（belongTo:"company", saveType:"read"，17 个系统字段） | 实测（2026-11-18） |
| 发件身份（系统通道昵称） | /mailbox/sender-list、sender-save、sender-add、sender-check | list 读实测；save 写读往返实测（2026-11-18 阶段 0）；add/check 源码级 |
| 平台产品档案（卖家档案） | /profile/product-list、product-add、product-save、product-delete、product-default | list 实测；add/save/delete 写往返实测（2026-11-18 阶段 0，五字段逐字一致）；default 未实测 |
| 邮箱验证（只用于一对一精发，见 SKILL §4.1 验证闸） | /contacts/contacts/verify（批量选区形状：{selectAll:false, selectKeys:[cid…], selectSort:{}, selectTotal:n}，一次提交只回一个 backendId） | 实测（2026-11-18：单个联系人提交后接口约 2.5 秒返回任务号，回读联系人 verify_status=valid、verify_time 已刷新；2026-11-19：2 人批量选区提交约 3 秒落回；落回时延不稳定——另有样本 150 秒未落回、300 秒不变，响应体不带结果、须按 SKILL §4.1 回读协议回读；大批量耗时未测） |
| 格式检查（非验证） | /tools/email-address-check | 定性实测（2026-11-19：只验邮箱格式，对不存在的域名同样返回 success，不返回有效性结论；源码口径为群发回信地址格式校验——**禁止当邮箱验证用**，验证一律走 /contacts/contacts/verify） |
| 智能跟进计划 | /sequences/*（建/步/加人/激活/报表） | 读：实测｜写：契约级（未实测） |
| 群发任务 | /tasks/mass/*（建/启/停/计数/配置） | 纯契约级（写未实测；计数接口仅证明可达，不算写验证） |
| 精发/收信/回复/追踪 | /mails/*（列表/打开/存稿/发送/状态/追踪） | 读：实测｜写：单发已实测（官方包配方，见「单发配方要点」）、其余契约级 |
| 每月权益领取（§1.6） | /expenses/give-status（查）、/expenses/give-get（领） | 读：实测｜领：契约级（未实测） |
| 点数/费用读数 | /account/*、/expenses/* | 读实测 |
| 禁发名单登记与查询（⑪） | /contacts/black/*（域名）、companies-black、contacts-black、/mails/mails-address-black | 契约级 |
| 绑箱状态查询/校验 | /mails/accounts-list、/mails/accounts-check | 契约级 |
| WhatsApp 会话（§4.4） | 无——不是平台功能，维持浏览器通道 | 不适用 |

两条边界写死：

- **绑箱动作不走接口**：绑定要填的授权码是凭据，不许经 AI 构造的请求体传递（R23）；绑定仍在来发信网页由用户本人填入（见《邮箱绑定指南》），接口只做两件事——查已绑账号列表、对已绑账号做连通性校验；凡要新填、重填授权码的动作一律回网页。
- **禁发名单**：登记与查询走上表黑名单接口（即平台禁发名单管理接口）；一切禁发类写操作（含 AI 评分结果里的「存禁发」）同为契约级、未实测；名单对发送的拦截效力以平台实际行为为准，本 skill 不另作保证，发送前四查（R13）照旧。
- **列表接口参数（实测范围）**：已实测的列表类接口（task-list、sender-list、companies/show）必须带 `filter:{}` 与 `sort:{}`，缺参返回 500；**还须带 `current`（页码）**，sender-list 等接口缺 current 不返回数据（实测）；其余列表接口未逐一验证，调用时默认同样带上，遇 500 或空返回先补此三参再排查。company-people 的 pageSize 须 ≥10（传小报 422，实测）。

## 单发配方要点（官方包实测，2026-11-17/18）

证据等级：**已实测（官方包配方）**——来源为官方 Agent 包 `references/workflows.md`「单发直发配方」，2026-11-17/18 在个人工作区（z7pvxh、仅系统账号、无绑定邮箱）经网页端与 API 双路实测发通并多轮修订；本 skill 侧首次使用仍按 SKILL.md §4 章首口径先小步验证。绑定邮箱通道的 `maid/sender` 取法见下（以 `/mails/accounts-list` 行与已发送记录为准），自有通道经 API 发送未逐项实测。

- **接口**：`POST /mails/sendmail-add`，与普通写信共用，无需先建模板或任务。最小请求体六个字段缺一不可：`maid`、`sender`、`to`、`subject`、`html`、`sendAtOnce`。
- **发件标识 `sender`**：必须用**完整标识**（形如 `1804106008.z7pvxh`）；只填发件人列表里的裸 `name` 会被拒，报「该邮箱无法发送，请联系客服解锁发送」——处置顺序写死：先核对发件标识、再查账号状态；这条报错不构成账号被锁的证据（实测对照：标识错误必报此错、换完整标识即发送成功）。完整标识从已发送记录（`POST /mails/mails-list`）读回、缓存复用；记录里有多个 `sender` 时按目标发件人的 `name` 后缀匹配、同后缀取最新；工作区还没有已发送记录时，从网页端写信窗的发件人下拉取。
- **收件人格式**：每个地址写 `<邮箱>` 或 `显示名 <邮箱>`，多人用英文逗号拼接；只写裸邮箱报「发送对象地址格式错误」。漏传 `sendAtOnce` 报「需要明确 sendAtOnce」。
- **`single`**：`true`＝分别发送（每个收件人单独一封、互不可见，发送状态总数＝收件人数）；省略或 `false`＝一封同达（收件端能看到全部收件人）。精发与多人发送必须显式传 `true`，单收件人直发同样用 `true`。
- **正文与附件**：`html` 字段传 HTML（段落 `<p>`、换行 `<br>`、加粗 `<strong>`）；只传纯文本会连成一段。附件先 `upload` 取得 `url/name/size` 再填 `attachments`（与附件库引用 `attIds` 别混）。
- **追踪**：`track: true` 在正文末尾埋追踪像素；打开数据查 `/mails/track-info`，参数 `sid` 取已发送记录的 `ssid` 字段（不是发送返回的 sendId）。真实打开事件回录未端到端验通，查到空数组不等于没人打开。
- **定时**：`sendAtOnce: false`＋`timeStart`（未来 90 天内的毫秒时间戳，缺失或超限后端明确报错）；提交返回邮件 `id`（不是 sendId），到点自动发出。改期 `/mails/change-timer`、取消 `/mails/cancel-timer`；取消是幂等的，取消后必须回查列表确认该记录落 Drafts 且 `timeStart` 为 null 才算生效。
- **发件昵称**：发送请求里不能临时设昵称（`fromName` 字段被忽略）；昵称是发件人身份属性，在发件人设置里维护（`/mailbox/sender-save`）。分通道口径（2026-11-19 定案）：**网页端发送时发件人名称真实生效**——网页端把主发件身份昵称改为测试名后网页真发 1 封，收件原始头 header_from_name 即为新昵称（改后已恢复原值）；**经 Agent API 单发时不带昵称**——把非主用发件身份的 fromName 改成测试值后经 API 发信，收件侧显示名仍是账号 userid；以 fromName 长期为「Tony」的发件身份发对照信、主身份历史已发送邮件，显示名同为 userid，合计 5 样本一致，对照组已排除「延迟生效」解释。即问题只在 API 单发路径：sender 的 fromName 改动未反映在 API 单发的收件侧显示名上。昵称设置本身（sender-save）写读往返已实测可用；经 API 单发又在意对外显示名的，走绑定邮箱通道。
- **系统通道注意**：`maid: "system"` 从平台大量轮换域名发出、扣通用点数，与群发共用同一平台系统通道，是正式发送通道之一。**运营实测（Tony 2026-11-18）**：收件人以企业邮箱为主时投递表现好、比免费邮箱更容易进收件箱，日量可达数千至数万封；实际量以平台账号额度与点数预算为界。**收件侧区分**：官方实测样本（数量有限）中直发 Gmail 均进垃圾箱——此为免费邮箱（Gmail 等）侧的小样本结论；名单混有免费邮箱收件人时单独分组、先小样实测，通道仍按 SKILL.md 优先级口径选（默认系统通道），只有满足例外 (b) 或用户明确指定时才改用绑定邮箱通道，企业邮箱与免费邮箱的结论不互相外推。平台账号侧有自身风控（发送被拒先核对发件标识、再查账号状态），禁发名单四查与熔断对系统通道同等适用（见 SKILL.md §4.2 路线丙与 §4.3）。`readReceipt`（已读回执）与 `priority`（优先级）在系统通道下不生效。

## 公司字段回写配方（modifyCompanies，实测 2026-11-18）

- **接口**：`POST /contacts/companies/save`（批量改字段口）。正解参数：`{selectAll:false, selectKeys:[公司_id], selectSort:{}, selectTotal:1, changeField:"<字段名>", changeType:"renew", changeValue:<新值>}`。踩坑记录：只传 {_id, 字段} 报 422（缺 selectTotal）；传 {ids:[...]} 返回 success 但 matchedCount=0（假成功），一律不用。
- **已实测可写字段**：short_description（公司简介，改＋恢复全程读回无残留）、phone_number（公司电话）。判读注意：同值写入 matchedCount=1、**modifiedCount=0**——是后端 no-op 语义，不等于字段不可写；改值写入 modifiedCount=1 且回读在位才算验通。
- **字段存在性以注册表为准**：`POST /fields/company-fields` {belongTo:"company", saveType:"read"} 返回 17 个系统字段（orgName、domain、website、countryCode、status、tags、employees、industry、phone_number、linkedin_url、facebook_url、twitter_url、founded、short_description、company_address、create_time、scoreLevels）。**公司没有 remark 字段**（记录转储/编辑表单/类型定义/字段注册表四源核实）；公司级备注走自定义字段补建（SKILL §4.1 B4，补建路径已实测——2026-11-19 网页端建并回验、失败降级）。联系人有 remark 与 source。

## 调用纪律（与 R29 同口径）

1. 接口命令默认先预览、确认无误才真执行；请求体走文件或标准输入，不拼进命令行。
2. **写操作结果不明（超时、断连、状态待确认）不自动重试**：先查状态对账再决定，防重复发送、重复建计划；台账先记「待确认」态、不记成功；该操作没有状态查询接口时（如群发启停），回网页核对实际状态再决定，仍核不清就报用户人工确认，不许凭猜测重发或宣布完成。
3. 读到「仍在处理」类状态不许报成已完成（如发信状态 pending ≠ 已发送）。
4. 每次接口操作的留痕按 §2.3 编号溯源记台账，与网页操作同等要求。

## 降级规则

| 情形 | 处置 |
| --- | --- |
| 接口返回未授权/作用域拒绝（401/403/203 等） | 停该操作 → 回网页完成 → 向用户说明原因；不换凭据、不换工作区 ID 硬闯 |
| 凭据到期/失效 | 重走网页授权（用户点一次允许）；走不通则全面回网页操作 |
| 通道整体不可用（宿主限制、装不上） | 全面回网页操作，设置页标 degraded 并向用户明示 |
| 账号级操作（改密码、绑身份、管理授权、建/入企业） | 官方凭据按设计不可用，一律回网页由用户本人完成 |
| 网络超时/限流/服务端错误（读操作） | 交官方客户端自带重试处理（等待递增、遵守服务端 Retry-After），AI 不叠加自己的重试；写操作不走客户端重试，按调用纪律第 2 条（先对账、无查询接口回网页核对） |

## R23 附注：代办边界与通知绑定代办链（C3 读码形态）

R23 红线不变：Muse 不存邮箱凭据、不模拟网页登录邮箱、不抓取任何会话令牌。在此之内的代办边界写死：

- **允许**：① 官方 Agent 通道授权的委托代办（§1.1 保险库路径：凭据经安全录入卡直达保险库、AI 只打开官方授权链接、核对用户码与工作空间后代点当次授权页的「允许」——仅限该次授权、一次性，用户码只用于当场核对、不写入任何记录）；② 通知绑定代办链中，用户本人扫码登录后，AI 代填来发信个人设置表单（填账号通知邮箱、点获取验证码）；验证码由 AI 在用户已登录的通知邮箱里只读验证码邮件取得后代填（读码形态，Tony 2026-11-19 裁定批准；只读验证码邮件、只用于本次绑定、读后不留存），读不到或用户不愿意时仍可由用户口述或粘贴。
- **禁止**：AI 输入任何账号密码、代扫码、读取或保存验证码以外的邮箱内容、保留用户邮箱的登录会话、把验证码写入任何记录。
- **C3 当前执行读码形态（Tony 2026-11-19 裁定）**：通知绑定时 AI 可读用户通知邮箱的验证码邮件完成绑定，护栏＝只读验证码邮件、只用于本次绑定、读后不留存；口述/粘贴代填仍可作为读不到码或用户不愿意时的回落。绑定对象是账号通知邮箱（`/account/renew-email` 变更的账号邮箱），与发件身份（mailbox/sender-*）是两套东西，不许混淆。
